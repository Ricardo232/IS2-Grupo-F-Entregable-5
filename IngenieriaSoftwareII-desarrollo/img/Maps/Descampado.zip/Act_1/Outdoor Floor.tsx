<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Outdoor Floor" tilewidth="40" tileheight="40" tilecount="4760" columns="40">
 <image source="PC Computer - Diablo 2 Diablo 2 Lord of Destruction - Outdoor Floor.png" trans="ff00ff" width="1601" height="4768"/>
</tileset>
