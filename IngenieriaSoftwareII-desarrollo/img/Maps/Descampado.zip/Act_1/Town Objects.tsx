<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Town Objects" tilewidth="40" tileheight="40" tilecount="8928" columns="144">
 <image source="PC Computer - Diablo 2 Diablo 2 Lord of Destruction - Town Objects.png" trans="ff00ff" width="5760" height="2502"/>
</tileset>
