<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Town2" tilewidth="40" tileheight="40" tilecount="20" columns="20">
 <image source="Town2.png" trans="ff00ff" width="800" height="79"/>
</tileset>
