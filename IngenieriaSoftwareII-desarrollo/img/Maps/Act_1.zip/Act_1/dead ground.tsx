<?xml version="1.0" encoding="UTF-8"?>
<tileset name="tristam dead ground" tilewidth="40" tileheight="40" tilecount="460" columns="20">
 <image source="tristam dead ground.png" trans="ff00ff" width="800" height="959"/>
</tileset>
