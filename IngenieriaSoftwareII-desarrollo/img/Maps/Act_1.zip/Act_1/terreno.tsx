<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Town" tilewidth="40" tileheight="40" tilecount="1460" columns="20">
 <image source="Town.png" trans="ff00ff" width="800" height="2959"/>
</tileset>
