<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Objetos1" tilewidth="40" tileheight="40" tilecount="2304" columns="144">
 <image source="Objetos1.png" trans="ff00ff" width="5760" height="642"/>
</tileset>
