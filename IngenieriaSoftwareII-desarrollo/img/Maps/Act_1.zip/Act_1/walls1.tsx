<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Walls" tilewidth="40" tileheight="40" tilecount="4356" columns="132">
 <image source="Walls.png" trans="ff00ff" width="5280" height="1346"/>
</tileset>
