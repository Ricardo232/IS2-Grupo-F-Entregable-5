<?xml version="1.0" encoding="UTF-8"?>
<tileset name="river" tilewidth="40" tileheight="40" tilecount="340" columns="20">
 <image source="river.png" trans="ff00ff" width="800" height="718"/>
</tileset>
